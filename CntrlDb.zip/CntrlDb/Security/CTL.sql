﻿CREATE SCHEMA [CTL]
    AUTHORIZATION [dbo];










