﻿CREATE TABLE [CTL].[Configuration] (
    [ConfigurationKey]   VARCHAR (255) NOT NULL,
    [ConfigurationValue] VARCHAR (255) NOT NULL
);

