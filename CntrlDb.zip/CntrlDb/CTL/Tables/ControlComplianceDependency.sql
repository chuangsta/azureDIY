﻿CREATE TABLE [CTL].[ControlComplianceDependency] (
    [TableName] VARCHAR (255) NULL
);

